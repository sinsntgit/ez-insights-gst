
export enum AppView {
  DASHBOARD = 'DASHBOARD',
  RECONCILIATION = 'RECONCILIATION',
  ITC_OPTIMIZATION = 'ITC_OPTIMIZATION',
  VENDOR_RISK = 'VENDOR_RISK',
  SCENARIO_ANALYSIS = 'SCENARIO_ANALYSIS',
  CONVERSATIONAL_AI = 'CONVERSATIONAL_AI',
  LIVE_AGENT = 'LIVE_AGENT'
}

export interface GSTDataPoint {
  period: string;
  state: string;
  branch: string;
  entity: string;
  businessLine: string;
  gstr1: number;
  gstr3b: number;
  gstr2b: number;
  books: number;
  eligibleITC: number;
  blockedITC: number;
  claimedITC: number;
  exposure: number;
  highRiskVendors: number;
  complianceScore: number;
}

export interface GlobalFilters {
  period: string;
  entity: string;
  state: string;
  branch: string;
  businessLine: string;
}

export interface Scenario {
  id: string;
  name: string;
  vendorImprovement: number; // 0-100%
  mismatchReduction: number; // 0-100%
  filingDelayReduction: number; // 0-100%
  rcmExposureChange: number; // -100 to 100%
}
