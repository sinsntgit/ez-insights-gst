
import { GSTDataPoint } from './types';

export const ENTITIES = ['ICICI Bank Ltd', 'ICICI Securities', 'ICICI Prudential'];
export const STATES = ['Maharashtra', 'Karnataka', 'Delhi', 'Tamil Nadu', 'Gujarat', 'West Bengal', 'Telangana'];
export const BUSINESS_LINES = ['Retail Banking', 'Corporate Banking', 'Treasury', 'Shared Services'];
export const PERIODS = ['Q1 FY24', 'Q2 FY24', 'Q3 FY24', 'Q4 FY24'];

export const BRANCHES_BY_STATE: Record<string, string[]> = {
  'Maharashtra': ['Mumbai Main', 'Pune Metro', 'Nagpur Central'],
  'Karnataka': ['Bangalore MG Road', 'Mysore Heritage', 'Hubli Hub'],
  'Delhi': ['CP Flagship', 'South Delhi Premium', 'Rohini Extension'],
  'Tamil Nadu': ['Chennai Corporate', 'Coimbatore Mills', 'Madurai Temple'],
  'Gujarat': ['Ahmedabad West', 'Surat Diamond', 'Vadodara Tech'],
  'West Bengal': ['Kolkata Park St', 'Durgapur Industrial'],
  'Telangana': ['Hyderabad HITEC', 'Warangal Gateway'],
};

export const generateMockData = (): GSTDataPoint[] => {
  const data: GSTDataPoint[] = [];
  
  PERIODS.forEach(period => {
    STATES.forEach(state => {
      ENTITIES.forEach(entity => {
        BUSINESS_LINES.forEach(line => {
          const branches = BRANCHES_BY_STATE[state] || ['Default Branch'];
          branches.forEach(branch => {
            const baseValue = Math.random() * 50 + 20; // In Cr
            const mismatch = (Math.random() - 0.5) * 5;
            const books = baseValue + (Math.random() * 5);
            
            data.push({
              period,
              state,
              branch,
              entity,
              businessLine: line,
              gstr1: baseValue,
              gstr3b: baseValue + mismatch,
              gstr2b: baseValue * 0.95,
              books: books,
              eligibleITC: baseValue * 0.8,
              blockedITC: baseValue * 0.1,
              claimedITC: baseValue * 0.75,
              exposure: Math.random() * 15,
              highRiskVendors: Math.floor(Math.random() * 20),
              complianceScore: 75 + Math.random() * 20
            });
          });
        });
      });
    });
  });
  
  return data;
};

export const VENDORS = [
  { name: 'Tech Solutions Ltd', score: 85, timeliness: 98, defaultHistory: 'None', itcImpact: 1.2, risk: 'Low' },
  { name: 'Sky High Infra', score: 42, timeliness: 65, defaultHistory: 'Frequent', itcImpact: 4.5, risk: 'High' },
  { name: 'Global Logistics', score: 68, timeliness: 82, defaultHistory: 'Occasional', itcImpact: 2.1, risk: 'Medium' },
  { name: 'Prime Office Supplies', score: 92, timeliness: 100, defaultHistory: 'None', itcImpact: 0.8, risk: 'Low' },
  { name: 'Data Systems Inc', score: 35, timeliness: 50, defaultHistory: 'Frequent', itcImpact: 5.8, risk: 'Critical' },
];

export const MISMATCHES = [
  { invoice: 'INV/24/001', vendor: 'Sky High Infra', type: 'Value Mismatch', amtBooks: 1500000, amtPortal: 1200000, diff: 300000, status: 'Urgent' },
  { invoice: 'INV/24/023', vendor: 'Data Systems Inc', type: 'Missing Invoice', amtBooks: 2500000, amtPortal: 0, diff: 2500000, status: 'Critical' },
  { invoice: 'INV/24/056', vendor: 'Global Logistics', type: 'Vendor Non-filing', amtBooks: 800000, amtPortal: 0, diff: 800000, status: 'Warning' },
  { invoice: 'INV/24/099', vendor: 'Tech Solutions Ltd', type: 'GSTIN Mismatch', amtBooks: 500000, amtPortal: 500000, diff: 0, status: 'Resolved' },
];
