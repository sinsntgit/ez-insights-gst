
import React, { useState, useMemo } from 'react';
import { 
  LayoutDashboard, 
  RefreshCcw, 
  TrendingUp, 
  ShieldAlert, 
  BarChart3, 
  MessageSquare,
  Mic,
  Filter,
  ChevronDown,
  Bell,
  Menu,
  ArrowRight
} from 'lucide-react';
import { AppView, GlobalFilters, GSTDataPoint, Scenario } from './types';
import { generateMockData, ENTITIES, STATES, BUSINESS_LINES, PERIODS, BRANCHES_BY_STATE } from './mockData';

// Components
import Dashboard from './components/Dashboard';
import Reconciliation from './components/Reconciliation';
import ITCOptimization from './components/ITCOptimization';
import VendorRisk from './components/VendorRisk';
import ScenarioAnalysis from './components/ScenarioAnalysis';
import Chat from './components/Chat';
import LiveAgent from './components/LiveAgent';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.DASHBOARD);
  const [filters, setFilters] = useState<GlobalFilters>({
    period: 'Q3 FY24',
    entity: 'ICICI Bank Ltd',
    state: 'All States',
    branch: 'All Branches',
    businessLine: 'All Lines'
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [scenarios, setScenarios] = useState<Scenario[]>([
    { id: 'baseline', name: 'Baseline', vendorImprovement: 0, mismatchReduction: 0, filingDelayReduction: 0, rcmExposureChange: 0 }
  ]);

  const allData = useMemo(() => generateMockData(), []);

  const filteredData = useMemo(() => {
    return allData.filter(d => {
      const matchPeriod = d.period === filters.period;
      const matchEntity = d.entity === filters.entity;
      const matchState = filters.state === 'All States' || d.state === filters.state;
      const matchBranch = filters.branch === 'All Branches' || d.branch === filters.branch;
      const matchLine = filters.businessLine === 'All Lines' || d.businessLine === filters.businessLine;
      return matchPeriod && matchEntity && matchState && matchBranch && matchLine;
    });
  }, [allData, filters]);

  const navItems = [
    { id: AppView.DASHBOARD, label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: AppView.RECONCILIATION, label: 'GST Reconciliation', icon: RefreshCcw },
    { id: AppView.ITC_OPTIMIZATION, label: 'ITC Optimization', icon: TrendingUp },
    { id: AppView.VENDOR_RISK, label: 'Vendor Risk', icon: ShieldAlert },
    { id: AppView.SCENARIO_ANALYSIS, label: 'Scenario Analysis', icon: BarChart3 },
    { id: AppView.CONVERSATIONAL_AI, label: 'Conversational AI', icon: MessageSquare },
    { id: AppView.LIVE_AGENT, label: 'Voice AI Expert', icon: Mic },
  ];

  const handleFilterChange = (key: keyof GlobalFilters, value: string) => {
    setFilters(prev => {
      const next = { ...prev, [key]: value };
      if (key === 'state') next.branch = 'All Branches';
      return next;
    });
  };

  const currentBranches = useMemo(() => {
    if (filters.state === 'All States') return [];
    return BRANCHES_BY_STATE[filters.state] || [];
  }, [filters.state]);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`bg-slate-900 text-slate-300 transition-all duration-300 ease-in-out z-40 fixed lg:static h-full ${isSidebarOpen ? 'w-64 translate-x-0' : 'w-20 -translate-x-full lg:translate-x-0'}`}>
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div className={`flex items-center gap-2 font-bold text-white text-xl transition-opacity ${!isSidebarOpen && 'lg:opacity-0'}`}>
            <span className="text-blue-500">Ez</span>Insights.ai
          </div>
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-1 hover:bg-slate-800 rounded hidden lg:block">
            <Menu className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`flex items-center gap-4 w-full p-3 rounded-lg transition-all duration-200 group ${activeView === item.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'hover:bg-slate-800'}`}
            >
              <item.icon className={`w-5 h-5 flex-shrink-0 ${activeView === item.id ? 'text-white' : 'text-slate-500 group-hover:text-white'}`} />
              <span className={`whitespace-nowrap font-medium transition-opacity ${!isSidebarOpen && 'lg:hidden'}`}>
                {item.label}
              </span>
            </button>
          ))}
        </nav>

        <div className={`absolute bottom-0 w-full p-6 border-t border-slate-800 transition-opacity ${!isSidebarOpen && 'lg:hidden'}`}>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-xs font-bold text-white ring-2 ring-slate-800">AK</div>
            <div>
              <div className="text-sm font-semibold text-white">Abhinav K.</div>
              <div className="text-xs opacity-60 uppercase tracking-tighter">Head of Indirect Tax</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-30 shadow-sm shadow-slate-100">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 hover:bg-slate-100 rounded">
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                {navItems.find(n => n.id === activeView)?.icon && React.createElement(navItems.find(n => n.id === activeView)!.icon, { className: "w-5 h-5 text-blue-600" })}
              </div>
              <h1 className="text-xl font-bold text-slate-800">
                {navItems.find(n => n.id === activeView)?.label}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2">
               <span className="text-[10px] font-bold text-emerald-600 px-2 py-0.5 bg-emerald-50 rounded uppercase animate-pulse">Connected</span>
               <div className="h-4 w-px bg-slate-200 mx-2"></div>
            </div>
            <div className="hidden md:flex bg-slate-100 rounded-lg p-1 border border-slate-200">
              <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors"
              >
                <Filter className="w-4 h-4" />
                Global Filters
                <ChevronDown className={`w-4 h-4 transition-transform ${isFilterOpen ? 'rotate-180' : ''}`} />
              </button>
            </div>
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        {/* Global Filter Bar (Expandable) */}
        {isFilterOpen && (
          <div className="bg-white border-b border-slate-200 p-6 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 animate-in slide-in-from-top duration-300 shadow-md z-20">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Financial Period</label>
              <select 
                value={filters.period} 
                onChange={(e) => handleFilterChange('period', e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              >
                {PERIODS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Entity</label>
              <select 
                value={filters.entity} 
                onChange={(e) => handleFilterChange('entity', e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              >
                {ENTITIES.map(e => <option key={e} value={e}>{e}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">State</label>
              <select 
                value={filters.state} 
                onChange={(e) => handleFilterChange('state', e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="All States">All States</option>
                {STATES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Branch</label>
              <select 
                value={filters.branch} 
                onChange={(e) => handleFilterChange('branch', e.target.value)}
                disabled={filters.state === 'All States'}
                className="w-full bg-slate-50 border border-slate-200 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none disabled:opacity-50"
              >
                <option value="All Branches">All Branches</option>
                {currentBranches.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div className="flex items-end pb-1">
              <button 
                onClick={() => setFilters({
                  period: 'Q3 FY24',
                  entity: 'ICICI Bank Ltd',
                  state: 'All States',
                  branch: 'All Branches',
                  businessLine: 'All Lines'
                })}
                className="w-full py-2 text-sm font-bold text-blue-600 border border-blue-600/20 hover:bg-blue-50 rounded-lg transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          </div>
        )}

        {/* View Container */}
        <div className="flex-1 overflow-y-auto bg-slate-50 p-6 space-y-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <span>{filters.entity}</span>
              <ArrowRight className="w-3 h-3 text-slate-300" />
              <span>{filters.period}</span>
              {filters.state !== 'All States' && (
                <>
                  <ArrowRight className="w-3 h-3 text-slate-300" />
                  <span className="text-blue-600">{filters.state}</span>
                </>
              )}
               {filters.branch !== 'All Branches' && (
                <>
                  <ArrowRight className="w-3 h-3 text-slate-300" />
                  <span className="text-indigo-600">{filters.branch}</span>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded text-[9px] font-black uppercase ring-1 ring-yellow-200">Simulated Dashboard</span>
            </div>
          </div>

          <div className="max-w-[1600px] mx-auto">
            {activeView === AppView.DASHBOARD && <Dashboard data={filteredData} />}
            {activeView === AppView.RECONCILIATION && <Reconciliation data={filteredData} />}
            {activeView === AppView.ITC_OPTIMIZATION && <ITCOptimization data={filteredData} />}
            {activeView === AppView.VENDOR_RISK && <VendorRisk data={filteredData} />}
            {activeView === AppView.SCENARIO_ANALYSIS && <ScenarioAnalysis data={filteredData} scenarios={scenarios} setScenarios={setScenarios} />}
            {activeView === AppView.CONVERSATIONAL_AI && <Chat data={filteredData} filters={filters} />}
            {activeView === AppView.LIVE_AGENT && <LiveAgent data={filteredData} filters={filters} />}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
