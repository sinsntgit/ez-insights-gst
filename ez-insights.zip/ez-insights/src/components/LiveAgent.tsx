
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, Volume2, Bot, Sparkles, BrainCircuit, Waves } from 'lucide-react';
import { GlobalFilters, GSTDataPoint } from '../types';

interface LiveAgentProps {
  data: GSTDataPoint[];
  filters: GlobalFilters;
}

const LiveAgent: React.FC<LiveAgentProps> = ({ data, filters }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcription, setTranscription] = useState<string>('');
  const [status, setStatus] = useState<'idle' | 'listening' | 'speaking' | 'connecting'>('idle');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Manual base64 encoding following SDK examples
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Manual base64 decoding following SDK examples
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  // Raw PCM audio decoding logic following SDK examples
  async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  const toggleSession = async () => {
    if (isActive) {
      setIsActive(false);
      setStatus('idle');
      sessionRef.current?.close();
      return;
    }

    setStatus('connecting');
    // Always use named parameter for apiKey and direct access to process.env.API_KEY
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Summary metrics for context
    const totalExposure = data.reduce((sum, d) => sum + d.exposure, 0).toFixed(2);
    const avgCompliance = (data.reduce((sum, d) => sum + d.complianceScore, 0) / (data.length || 1)).toFixed(1);

    const sessionPromise = ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks: {
        onopen: async () => {
          setIsActive(true);
          setStatus('listening');
          
          inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const source = inputAudioContextRef.current.createMediaStreamSource(stream);
          const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
          
          scriptProcessor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const int16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
            // Send audio input only after session resolves to prevent race conditions
            sessionPromise.then(s => s.sendRealtimeInput({
              media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' }
            }));
          };
          source.connect(scriptProcessor);
          scriptProcessor.connect(inputAudioContextRef.current.destination);
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle both model and input transcriptions if enabled
          if (message.serverContent?.outputTranscription) {
            setTranscription(prev => prev + ' ' + message.serverContent?.outputTranscription?.text);
          }

          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio) {
            setStatus('speaking');
            if (!audioContextRef.current) audioContextRef.current = new AudioContext({ sampleRate: 24000 });
            const ctx = audioContextRef.current;
            // Use tracking timestamp for gapless playback
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(ctx.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
            sourcesRef.current.add(source);
            source.onended = () => {
              sourcesRef.current.delete(source);
              if (sourcesRef.current.size === 0) setStatus('listening');
            };
          }

          // Handle interruptions correctly by stopping playback queue
          if (message.serverContent?.interrupted) {
            sourcesRef.current.forEach(s => s.stop());
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
            setStatus('listening');
          }
        },
        onclose: () => setIsActive(false),
        onerror: () => setStatus('idle'),
      },
      config: {
        responseModalities: [Modality.AUDIO],
        outputAudioTranscription: {},
        systemInstruction: `You are the EzInsights AI Executive Assistant. 
        You have direct access to the bank's GST data for ${filters.entity} (${filters.period}).
        Current metrics: Exposure is ₹${totalExposure} Cr, Compliance is ${avgCompliance}%.
        Speak naturally, professionally, and keep answers helpful for a CXO level executive.
        Wait for them to finish speaking. If interrupted, stop immediately.`
      }
    });

    sessionRef.current = await sessionPromise;
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-6 animate-in fade-in duration-1000">
      <div className="bg-slate-900 rounded-3xl p-12 shadow-2xl shadow-blue-900/40 relative overflow-hidden flex flex-col items-center text-center">
        {/* Background Accents */}
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/10 via-transparent to-indigo-600/10 pointer-events-none"></div>
        <div className="absolute -top-24 -left-24 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
        
        <div className="relative mb-12">
           <div className={`w-32 h-32 rounded-full bg-slate-800 flex items-center justify-center relative z-10 ${isActive ? 'ring-4 ring-blue-500 ring-offset-8 ring-offset-slate-900 animate-pulse' : ''}`}>
              {isActive ? (
                <Waves className={`w-12 h-12 text-blue-400 ${status === 'speaking' ? 'animate-bounce' : ''}`} />
              ) : (
                <BrainCircuit className="w-12 h-12 text-slate-500" />
              )}
           </div>
           {isActive && (
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-40 h-40 rounded-full border border-blue-500/30 animate-ping"></div>
             </div>
           )}
        </div>

        <h2 className="text-3xl font-black text-white mb-4 tracking-tight">EzInsights Voice Expert</h2>
        <p className="text-slate-400 max-w-lg mb-12 leading-relaxed">
          Talk naturally to your tax data. Ask about risks, recovery potential, or state-wise compliance without touching a single button.
        </p>

        <div className="flex flex-col items-center gap-8 w-full max-w-md">
          <button 
            onClick={toggleSession}
            disabled={status === 'connecting'}
            className={`group relative flex items-center gap-4 px-8 py-4 rounded-full font-black text-lg transition-all transform active:scale-95 ${isActive ? 'bg-rose-600 hover:bg-rose-700 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          >
            {isActive ? (
              <>
                <MicOff className="w-6 h-6" />
                Stop Interaction
              </>
            ) : (
              <>
                <Mic className="w-6 h-6 group-hover:animate-bounce" />
                {status === 'connecting' ? 'Initializing...' : 'Start Voice Analysis'}
              </>
            )}
          </button>

          <div className="w-full h-32 bg-slate-800/50 rounded-2xl border border-slate-700 p-6 flex flex-col justify-center overflow-hidden">
            <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Real-time Transcript</p>
            <p className="text-slate-300 text-sm line-clamp-3 italic">
              {isActive ? (transcription || "Listening for your query...") : "Expert is currently offline."}
            </p>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-8 w-full border-t border-slate-800 pt-12">
          <AgentFeature icon={<Sparkles className="w-4 h-4" />} label="Zero Latency" desc="Powered by Gemini Live" />
          <AgentFeature icon={<Volume2 className="w-4 h-4" />} label="Natural Voice" desc="Human-like synthesis" />
          <AgentFeature icon={<Bot className="w-4 h-4" />} label="Tax-Native" desc="Trained on GST laws" />
        </div>
      </div>
    </div>
  );
};

const AgentFeature: React.FC<{ icon: React.ReactNode; label: string; desc: string }> = ({ icon, label, desc }) => (
  <div className="flex flex-col items-center gap-2">
    <div className="p-2 bg-slate-800 rounded-lg text-blue-400">{icon}</div>
    <p className="text-xs font-black text-white uppercase tracking-tighter">{label}</p>
    <p className="text-[10px] text-slate-500 uppercase font-bold">{desc}</p>
  </div>
);

export default LiveAgent;
