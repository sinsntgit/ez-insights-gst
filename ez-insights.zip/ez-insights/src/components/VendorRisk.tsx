
import React from 'react';
import { 
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ZAxis, Cell
} from 'recharts';
import { ShieldAlert, ShieldCheck, UserMinus, Mail, Search, ExternalLink } from 'lucide-react';
import { VENDORS } from '../mockData';
import { GSTDataPoint } from '../types';

// Interface for VendorRisk props to resolve type errors in App.tsx
interface VendorRiskProps {
  data: GSTDataPoint[];
}

// Updated component to accept the data prop passed from App.tsx
const VendorRisk: React.FC<VendorRiskProps> = ({ data }) => {
  const riskData = VENDORS.map(v => ({
    name: v.name,
    score: v.score,
    itc: v.itcImpact,
    risk: v.risk
  }));

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Scatter Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-800">Vendor Risk Landscape</h3>
            <div className="flex gap-4 text-xs font-semibold">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> Low</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-500"></span> Medium</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-rose-500"></span> High</span>
            </div>
          </div>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis type="number" dataKey="score" name="Compliance Score" unit="" domain={[0, 100]} axisLine={false} tickLine={false} />
                <YAxis type="number" dataKey="itc" name="ITC Impact" unit=" Cr" axisLine={false} tickLine={false} />
                <ZAxis type="number" range={[100, 500]} />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter name="Vendors" data={riskData}>
                  {riskData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={
                      entry.risk === 'Low' ? '#10b981' : 
                      entry.risk === 'Medium' ? '#f59e0b' : 
                      '#ef4444'
                    } />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 p-4 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-between">
            <p className="text-xs text-slate-500 max-w-md">
              The chart correlates Compliance Scores with financial ITC impact. High-impact, low-score vendors (Top Left) require immediate attention.
            </p>
            <button className="text-blue-600 text-xs font-bold uppercase hover:underline">Download Data</button>
          </div>
        </div>

        {/* Global Stats */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Compliance Overview</h4>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-50 rounded-lg"><ShieldCheck className="w-5 h-5 text-emerald-600" /></div>
                  <div>
                    <p className="text-sm font-bold">Compliant Vendors</p>
                    <p className="text-[10px] text-slate-400">Score &gt; 85</p>
                  </div>
                </div>
                <span className="text-lg font-bold">65%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-50 rounded-lg"><ShieldAlert className="w-5 h-5 text-amber-600" /></div>
                  <div>
                    <p className="text-sm font-bold">Medium Risk</p>
                    <p className="text-[10px] text-slate-400">Score 50 - 85</p>
                  </div>
                </div>
                <span className="text-lg font-bold">22%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-rose-50 rounded-lg"><UserMinus className="w-5 h-5 text-rose-600" /></div>
                  <div>
                    <p className="text-sm font-bold">High Risk</p>
                    <p className="text-[10px] text-slate-400">Score &lt; 50</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-rose-600">13%</span>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-6 rounded-xl shadow-lg text-white">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Urgent Actions</h4>
            <div className="space-y-4">
              <div className="p-3 bg-white/5 border border-white/10 rounded-lg">
                <p className="text-xs font-bold mb-1">Notice Issued: Data Systems Inc</p>
                <p className="text-[10px] opacity-60 italic mb-2">Non-filing since Q2</p>
                <button className="text-[10px] font-bold text-blue-400 hover:text-blue-300">VIEW CASE</button>
              </div>
              <div className="p-3 bg-white/5 border border-white/10 rounded-lg">
                <p className="text-xs font-bold mb-1">Flagged: Sky High Infra</p>
                <p className="text-[10px] opacity-60 italic mb-2">₹4.5 Cr ITC at risk</p>
                <button className="text-[10px] font-bold text-blue-400 hover:text-blue-300 uppercase">SEND FOLLOW-UP</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Vendor Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-800">Top Non-Compliant Vendors</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filter by name..." 
              className="pl-10 pr-4 py-1.5 border border-slate-200 rounded-lg text-xs bg-slate-50"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Vendor Name</th>
                <th className="px-6 py-4">Compliance Score</th>
                <th className="px-6 py-4">Filing Timeliness</th>
                <th className="px-6 py-4">Default History</th>
                <th className="px-6 py-4 text-right">ITC Impact</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {VENDORS.map((vendor, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="px-6 py-4 font-semibold text-slate-900">{vendor.name}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div className={`h-full ${vendor.score > 80 ? 'bg-emerald-500' : vendor.score > 50 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${vendor.score}%` }}></div>
                      </div>
                      <span className="text-xs font-bold">{vendor.score}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-600">{vendor.timeliness}%</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded ${
                      vendor.defaultHistory === 'None' ? 'bg-emerald-50 text-emerald-700' : 
                      vendor.defaultHistory === 'Occasional' ? 'bg-amber-50 text-amber-700' : 
                      'bg-rose-50 text-rose-700'
                    }`}>
                      {vendor.defaultHistory}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right font-bold text-slate-900">₹{vendor.itcImpact} Cr</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg" title="Send Email">
                        <Mail className="w-4 h-4" />
                      </button>
                      <button className="p-2 hover:bg-slate-100 text-slate-600 rounded-lg" title="View Details">
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default VendorRisk;
