
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Cell, Legend
} from 'recharts';
import { Zap, TrendingUp, AlertCircle, Clock, Lightbulb } from 'lucide-react';
import { GSTDataPoint } from '../types';

interface ITCOptimizationProps {
  data: GSTDataPoint[];
}

const ITCOptimization: React.FC<ITCOptimizationProps> = ({ data }) => {
  const agingData = [
    { range: '0-30 Days', amount: 45.2, color: '#10b981' },
    { range: '31-60 Days', amount: 28.5, color: '#3b82f6' },
    { range: '61-90 Days', amount: 15.8, color: '#f59e0b' },
    { range: '>90 Days', amount: 8.4, color: '#ef4444' },
  ];

  const summary = useMemo(() => {
    const total = data.reduce((acc, curr) => ({
      eligible: acc.eligible + curr.eligibleITC,
      claimed: acc.claimed + curr.claimedITC,
      blocked: acc.blocked + curr.blockedITC,
    }), { eligible: 0, claimed: 0, blocked: 0 });
    
    return {
      eligible: total.eligible.toFixed(2),
      claimed: total.claimed.toFixed(2),
      blocked: total.blocked.toFixed(2),
      recoveryPotential: (total.eligible - total.claimed).toFixed(2)
    };
  }, [data]);

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Stats */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm overflow-hidden relative">
            <TrendingUp className="absolute bottom-[-10px] right-[-10px] w-24 h-24 text-emerald-500/5" />
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Claimed ITC</h4>
            <p className="text-2xl font-bold text-slate-900">₹{summary.claimed} Cr</p>
            <p className="text-xs text-emerald-600 mt-2 font-medium">92% of Total Eligible</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm overflow-hidden relative">
            <AlertCircle className="absolute bottom-[-10px] right-[-10px] w-24 h-24 text-red-500/5" />
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Blocked / Ineligible</h4>
            <p className="text-2xl font-bold text-red-600">₹{summary.blocked} Cr</p>
            <p className="text-xs text-slate-500 mt-2 font-medium">Invoices from Defaulting Vendors</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-blue-200 bg-blue-50/30 shadow-sm overflow-hidden relative">
            <Zap className="absolute bottom-[-10px] right-[-10px] w-24 h-24 text-blue-500/10" />
            <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest mb-2">Potential Recovery</h4>
            <p className="text-2xl font-bold text-blue-700">₹{summary.recoveryPotential} Cr</p>
            <p className="text-xs text-blue-500 mt-2 font-medium">Auto-identified via GSTR-2B matching</p>
          </div>
        </div>

        {/* AI Insight Sidebar */}
        <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-1.5 bg-blue-500 rounded-lg">
                <Lightbulb className="w-4 h-4" />
              </div>
              <h3 className="font-bold">AI Insight</h3>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              "₹{summary.recoveryPotential} Cr ITC is recoverable if vendor compliance improves by just 15% across the Treasury and Corporate Banking segments."
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-xs">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                <span className="text-slate-400">Maharashtra accounts for 42% of leakage</span>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                <span className="text-slate-400">5 Vendors flagged for non-filing status</span>
              </div>
            </div>
          </div>
          <button className="mt-8 w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold uppercase tracking-widest transition-colors">
            Run Auto-Followup
          </button>
        </div>
      </div>

      {/* ITC Aging View */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 rounded-lg">
              <Clock className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800">ITC Aging Analysis</h3>
              <p className="text-xs text-slate-500">Unclaimed ITC categorized by invoice age</p>
            </div>
          </div>
          <select className="bg-slate-50 border border-slate-200 text-xs font-semibold px-3 py-1.5 rounded-lg">
            <option>All Business Lines</option>
            <option>Retail Banking</option>
            <option>Corporate</option>
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agingData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="range" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="amount" radius={[4, 4, 0, 0]} barSize={60}>
                  {agingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-6">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Efficiency Metrics</h4>
            <div className="space-y-4">
              <MetricItem label="Avg. Days to Claim" value="28 Days" progress={85} />
              <MetricItem label="Late Filing Impact" value="₹1.2 Cr" progress={30} color="bg-rose-500" />
              <MetricItem label="Automation Level" value="65%" progress={65} color="bg-blue-500" />
            </div>
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-100 mt-6">
              <p className="text-[10px] font-bold text-amber-800 uppercase mb-2">Critical Action</p>
              <p className="text-xs text-amber-700 leading-relaxed">
                8.4 Cr ITC in the >90 days bucket is approaching the section 16(4) deadline for FY23-24. Recommend prioritizing these for immediate reconciliation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricItem: React.FC<{ label: string; value: string; progress: number; color?: string }> = ({ label, value, progress, color = "bg-emerald-500" }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="font-bold text-slate-800">{value}</span>
    </div>
    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
      <div className={`h-full ${color}`} style={{ width: `${progress}%` }}></div>
    </div>
  </div>
);

export default ITCOptimization;
