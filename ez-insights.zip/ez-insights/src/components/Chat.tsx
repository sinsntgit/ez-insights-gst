
import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Sparkles, Database, PlusCircle, AlertCircle, ShieldAlert
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { GlobalFilters, GSTDataPoint } from '../types';
import { ENTITIES, STATES, PERIODS } from '../mockData';

interface ChatProps {
  data: GSTDataPoint[];
  filters: GlobalFilters;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const Chat: React.FC<ChatProps> = ({ data: initialData, filters: initialFilters }) => {
  const [localFilters, setLocalFilters] = useState({
    entity: initialFilters.entity,
    period: initialFilters.period,
    state: initialFilters.state
  });

  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'assistant', 
      content: "The fill rate for the last quarter was 94.2%, which is an increase of 1.5% compared to the previous quarter. This improvement is driven by better demand forecasting and supplier reliability improvements in North America and Asia Pacific regions." 
    }
  ]);
  
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const contextData = initialData.filter(d => 
        d.entity === localFilters.entity && 
        d.period === localFilters.period && 
        (localFilters.state === 'All States' || d.state === localFilters.state)
      );

      const totalExposure = contextData.reduce((sum, d) => sum + d.exposure, 0).toFixed(2);
      const avgCompliance = (contextData.reduce((sum, d) => sum + d.complianceScore, 0) / (contextData.length || 1)).toFixed(1);

      const systemInstruction = `
        You are EzInsights AI, an expert GST consultant.
        Source: ${localFilters.entity}, Period: ${localFilters.period}, State: ${localFilters.state}.
        Context: Exposure ₹${totalExposure} Cr, Compliance ${avgCompliance}%.
        Format: Direct, professional, and data-driven text. No markdown symbols unless necessary.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: { systemInstruction, temperature: 0.7 }
      });

      const aiText = response.text || "I apologize, but I couldn't retrieve that information. Please try refining your question.";
      setMessages(prev => [...prev, { role: 'assistant', content: aiText }]);
    } catch (error) {
      console.error('AI Error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: "An error occurred during information retrieval. Please check your connectivity." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = () => {
    setMessages([{ role: 'assistant', content: "Session reset. Ask a question regarding your GST data to begin analysis." }]);
  };

  return (
    <div className="flex flex-col bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden h-[calc(100vh-160px)]">
      
      {/* 1. DATA SOURCE SELECTION (Top Bar) */}
      <div className="px-6 py-3 bg-slate-900 flex items-center gap-4 shrink-0 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-2 text-white shrink-0">
          <Database className="w-4 h-4 text-blue-400" />
          <span className="text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">Source Selection</span>
        </div>
        
        <div className="flex gap-3">
          <select 
            value={localFilters.entity} 
            onChange={(e) => setLocalFilters({...localFilters, entity: e.target.value})}
            className="bg-white/10 border border-white/20 text-white text-[11px] font-bold rounded-md px-3 py-1.5 outline-none cursor-pointer hover:bg-white/20 transition-all"
          >
            {ENTITIES.map(e => <option key={e} value={e} className="bg-slate-900">{e}</option>)}
          </select>
          
          <select 
            value={localFilters.period} 
            onChange={(e) => setLocalFilters({...localFilters, period: e.target.value})}
            className="bg-white/10 border border-white/20 text-white text-[11px] font-bold rounded-md px-3 py-1.5 outline-none cursor-pointer hover:bg-white/20 transition-all"
          >
            {PERIODS.map(p => <option key={p} value={p} className="bg-slate-900">{p}</option>)}
          </select>

          <select 
            value={localFilters.state} 
            onChange={(e) => setLocalFilters({...localFilters, state: e.target.value})}
            className="bg-white/10 border border-white/20 text-white text-[11px] font-bold rounded-md px-3 py-1.5 outline-none cursor-pointer hover:bg-white/20 transition-all"
          >
            <option value="All States" className="bg-slate-900">All States</option>
            {STATES.map(s => <option key={s} value={s} className="bg-slate-900">{s}</option>)}
          </select>
        </div>

        <div className="flex-1"></div>

        <button onClick={clearChat} className="p-2 text-slate-400 hover:text-white transition-all" title="Reset Session">
          <PlusCircle className="w-5 h-5" />
        </button>
      </div>

      {/* 2. SUGGESTIONS (Top visible bar) */}
      <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center gap-3 overflow-x-auto no-scrollbar shrink-0">
        <Sparkles className="w-3.5 h-3.5 text-blue-500 shrink-0" />
        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest shrink-0 mr-1">Discovery:</span>
        {[
          "Analyze Q3 leakage",
          "Identify risk nodes",
          "Maharashtra trend",
          "Exposure summary"
        ].map((q, i) => (
          <button 
            key={i}
            onClick={() => setInput(q)}
            className="px-3 py-1 bg-white border border-slate-200 rounded-md text-[9px] font-bold text-slate-500 hover:bg-blue-50 hover:text-blue-600 transition-all whitespace-nowrap"
          >
            {q}
          </button>
        ))}
      </div>

      {/* 3. CONVERSATION AREA */}
      <div 
        ref={scrollRef} 
        className="flex-1 overflow-y-auto p-8 bg-white"
      >
        <div className="max-w-4xl mx-auto space-y-10">
          {messages.map((msg, idx) => {
            if (msg.role === 'user') {
              return (
                <div key={idx} className="flex justify-start">
                  <div className="bg-[#eef5ff] border border-[#d1e4ff] text-[#0066ff] px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 shadow-sm">
                    <span className="font-bold shrink-0">Q: •</span> 
                    <span>{msg.content}</span>
                  </div>
                </div>
              );
            }
            return (
              <div key={idx} className="text-slate-700 text-[15px] leading-relaxed animate-in fade-in duration-500">
                {msg.content.split('\n').map((line, i) => (
                  <p key={i} className={i > 0 ? 'mt-4' : ''}>{line}</p>
                ))}
              </div>
            );
          })}
          
          {isTyping && (
            <div className="flex items-center gap-2 text-slate-400 text-sm animate-pulse">
              <Sparkles className="w-4 h-4 text-blue-400" /> 
              <span>Consulting Intelligence Core...</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. ASK A QUESTION FOOTER (As per screenshot) */}
      <div className="p-6 bg-white border-t border-slate-200 shrink-0">
        <div className="max-w-4xl mx-auto border border-slate-200 rounded-xl p-6 shadow-sm">
          <h4 className="text-sm font-bold text-slate-800 mb-4">Ask a Question</h4>
          
          <div className="flex flex-col gap-4">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask questions like: Why did fill rate drop last quarter in Europe?"
              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg focus:border-blue-300 focus:ring-1 focus:ring-blue-50 outline-none transition-all text-slate-600 text-sm placeholder:text-slate-400"
            />
            
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="w-fit flex items-center gap-2 px-5 py-2.5 bg-[#7eb0e3] hover:bg-[#6899ca] disabled:bg-slate-200 text-white rounded-md transition-all shadow-sm active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span className="text-sm font-medium">Execute</span>
            </button>
          </div>
          
          <div className="mt-6 flex items-center justify-between opacity-40 pt-4 border-t border-slate-50">
            <div className="flex items-center gap-2 text-[9px] font-black text-slate-500 uppercase tracking-widest">
              <ShieldAlert className="w-3 h-3" /> Secure Ledger Access
            </div>
            <div className="flex items-center gap-2 text-[9px] font-black text-slate-500 uppercase tracking-widest">
              <AlertCircle className="w-3 h-3" /> Real-time Analytics
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
