
import React, { useState } from 'react';
import { Search, AlertTriangle, FileWarning, CheckCircle, ArrowRight, Download } from 'lucide-react';
import { MISMATCHES } from '../mockData';
import { GSTDataPoint } from '../types';

interface ReconciliationProps {
  data: GSTDataPoint[];
}

const Reconciliation: React.FC<ReconciliationProps> = ({ data }) => {
  const [threshold, setThreshold] = useState(100000);
  const [filterType, setFilterType] = useState('All');

  const totals = data.reduce((acc, curr) => ({
    gstr1: acc.gstr1 + curr.gstr1,
    gstr3b: acc.gstr3b + curr.gstr3b,
    gstr2b: acc.gstr2b + curr.gstr2b,
    books: acc.books + curr.books,
  }), { gstr1: 0, gstr3b: 0, gstr2b: 0, books: 0 });

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom duration-500">
      {/* Top Level Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">GSTR-1 vs GSTR-3B</h3>
            <span className="px-2 py-1 bg-blue-50 text-blue-700 text-[10px] font-bold rounded">MONTHLY VIEW</span>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Total Liability (GSTR-1)</span>
              <span className="text-lg font-bold">₹{totals.gstr1.toFixed(2)} Cr</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Paid Liability (GSTR-3B)</span>
              <span className="text-lg font-bold">₹{totals.gstr3b.toFixed(2)} Cr</span>
            </div>
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-sm font-semibold">Net Mismatch</span>
              <span className={`text-lg font-bold ${Math.abs(totals.gstr1 - totals.gstr3b) > 1 ? 'text-red-600' : 'text-emerald-600'}`}>
                ₹{Math.abs(totals.gstr1 - totals.gstr3b).toFixed(2)} Cr
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">GSTR-2B vs Books (ITC)</h3>
            <span className="px-2 py-1 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded">MONTHLY VIEW</span>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Available in Portal (2B)</span>
              <span className="text-lg font-bold">₹{totals.gstr2b.toFixed(2)} Cr</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Recorded in Books</span>
              <span className="text-lg font-bold">₹{totals.books.toFixed(2)} Cr</span>
            </div>
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-sm font-semibold">Potential ITC Leakage</span>
              <span className="text-lg font-bold text-amber-600">
                ₹{Math.max(0, totals.books - totals.gstr2b).toFixed(2)} Cr
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mismatch Explorer */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <h3 className="font-bold text-slate-800">Invoice Level Mismatch Table</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search invoice or vendor..." 
                className="pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none w-64"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Threshold: ₹{threshold.toLocaleString()}</label>
              <input 
                type="range" 
                min="0" 
                max="1000000" 
                step="50000" 
                value={threshold}
                onChange={(e) => setThreshold(parseInt(e.target.value))}
                className="w-32 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>
            <button className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium transition-colors">
              <Download className="w-4 h-4" />
              Export Detailed Report
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Invoice #</th>
                <th className="px-6 py-4">Vendor Name</th>
                <th className="px-6 py-4">Issue Category</th>
                <th className="px-6 py-4 text-right">Amt (Books)</th>
                <th className="px-6 py-4 text-right">Amt (Portal)</th>
                <th className="px-6 py-4 text-right">Difference</th>
                <th className="px-6 py-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {MISMATCHES.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 font-mono font-medium text-slate-900">{item.invoice}</td>
                  <td className="px-6 py-4 text-slate-600">{item.vendor}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      item.status === 'Critical' ? 'bg-red-50 text-red-700' :
                      item.status === 'Urgent' ? 'bg-orange-50 text-orange-700' :
                      item.status === 'Warning' ? 'bg-amber-50 text-amber-700' :
                      'bg-emerald-50 text-emerald-700'
                    }`}>
                      {item.status === 'Critical' ? <AlertTriangle className="w-3 h-3" /> :
                       item.status === 'Resolved' ? <CheckCircle className="w-3 h-3" /> :
                       <FileWarning className="w-3 h-3" />}
                      {item.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">₹{item.amtBooks.toLocaleString()}</td>
                  <td className="px-6 py-4 text-right">₹{item.amtPortal.toLocaleString()}</td>
                  <td className="px-6 py-4 text-right font-bold text-red-600">₹{item.diff.toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <button className="p-2 hover:bg-slate-100 rounded-lg text-blue-600">
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reconciliation;
