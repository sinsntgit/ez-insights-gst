
import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Legend, Cell
} from 'recharts';
import { 
  Play, RotateCcw, Plus, Trash2, ArrowUpRight, ArrowDownRight, 
  Layers, ArrowRight, Save, Copy, LayoutGrid, ListFilter, CheckCircle2, Lock
} from 'lucide-react';
import { Scenario, GSTDataPoint } from '../types';

interface ScenarioAnalysisProps {
  data: GSTDataPoint[];
  scenarios: Scenario[];
  setScenarios: React.Dispatch<React.SetStateAction<Scenario[]>>;
}

const ScenarioAnalysis: React.FC<ScenarioAnalysisProps> = ({ data, scenarios, setScenarios }) => {
  const [editingId, setEditingId] = useState<string>('baseline');
  const [viewMode, setViewMode] = useState<'edit' | 'compare'>('edit');
  const [showSaveToast, setShowSaveToast] = useState(false);
  
  const currentScenario = useMemo(() => 
    scenarios.find(s => s.id === editingId) || scenarios[0]
  , [scenarios, editingId]);

  const baselineStats = useMemo(() => {
    const exposure = data.reduce((sum, d) => sum + d.exposure, 0);
    const itc = data.reduce((sum, d) => sum + d.claimedITC, 0);
    const leakage = data.reduce((sum, d) => sum + (d.eligibleITC - d.claimedITC), 0);
    const score = data.reduce((sum, d) => sum + d.complianceScore, 0) / (data.length || 1);
    
    return { exposure, itc, leakage, score };
  }, [data]);

  const calculateImpact = (scenario: Scenario) => {
    const itcRecovery = baselineStats.leakage * (scenario.vendorImprovement / 100);
    const exposureReduction = baselineStats.exposure * (scenario.mismatchReduction / 100);
    const complianceImprovement = scenario.vendorImprovement * 0.5;

    return {
      exposure: baselineStats.exposure - exposureReduction,
      itc: baselineStats.itc + itcRecovery,
      score: Math.min(100, baselineStats.score + complianceImprovement),
      deltaItc: itcRecovery,
      deltaExposure: exposureReduction,
    };
  };

  const handleSliderChange = (key: keyof Scenario, value: number) => {
    if (editingId === 'baseline') return;
    setScenarios(prev => prev.map(s => s.id === editingId ? { ...s, [key]: value } : s));
  };

  const createNewScenario = () => {
    const id = `scenario-${Date.now()}`;
    const newScenario: Scenario = {
      id,
      name: `Scenario ${scenarios.length}`,
      vendorImprovement: 10,
      mismatchReduction: 5,
      filingDelayReduction: 0,
      rcmExposureChange: 0
    };
    setScenarios([...scenarios, newScenario]);
    setEditingId(id);
    setViewMode('edit');
  };

  const saveScenario = () => {
    setShowSaveToast(true);
    setTimeout(() => setShowSaveToast(false), 2000);
  };

  const comparisonData = scenarios.map(s => {
    const results = calculateImpact(s);
    return {
      name: s.name,
      'Exposure': Number(results.exposure.toFixed(2)),
      'ITC Recovery': Number(results.itc.toFixed(2)),
      'Compliance': Number(results.score.toFixed(1)),
      id: s.id
    };
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Simulation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setViewMode('edit')}
            className={`px-6 py-2 rounded-lg text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all ${viewMode === 'edit' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
          >
            <ListFilter className="w-4 h-4" /> Simulate
          </button>
          <button 
            onClick={() => setViewMode('compare')}
            className={`px-6 py-2 rounded-lg text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all ${viewMode === 'compare' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:bg-white/50'}`}
          >
            <LayoutGrid className="w-4 h-4" /> Compare
          </button>
        </div>
        <button 
          onClick={createNewScenario}
          className="px-6 py-2 bg-slate-900 text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-blue-600 transition-all shadow-lg shadow-slate-900/10"
        >
          <Plus className="w-4 h-4" /> Create New Simulation
        </button>
      </div>

      {viewMode === 'edit' ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Scenario Selection Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6">Saved Strategies</h3>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {scenarios.map(s => (
                  <div key={s.id} className="group relative">
                    <button
                      onClick={() => setEditingId(s.id)}
                      className={`w-full p-4 rounded-2xl flex flex-col items-start transition-all border ${editingId === s.id ? 'bg-slate-900 border-slate-900 shadow-xl' : 'bg-white border-slate-100 hover:border-slate-300'}`}
                    >
                      <span className={`text-sm font-bold ${editingId === s.id ? 'text-white' : 'text-slate-700'}`}>{s.name}</span>
                      <span className={`text-[10px] uppercase font-black mt-1 ${editingId === s.id ? 'text-blue-400' : 'text-slate-400'}`}>
                        {s.id === 'baseline' ? 'System Baseline' : 'Executive Plan'}
                      </span>
                    </button>
                    {s.id !== 'baseline' && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); setScenarios(prev => prev.filter(x => x.id !== s.id)); setEditingId('baseline'); }}
                        className={`absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all ${editingId === s.id ? 'text-white/40 hover:text-white' : 'text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100'}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Parameters Controls */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden">
              {editingId === 'baseline' && (
                <div className="absolute inset-0 bg-white/60 backdrop-blur-[1px] z-10 flex flex-col items-center justify-center p-8 text-center">
                  <div className="p-3 bg-slate-100 rounded-full mb-4">
                    <Lock className="w-6 h-6 text-slate-400" />
                  </div>
                  <p className="text-sm font-black text-slate-600 uppercase tracking-tight">Baseline Locked</p>
                  <p className="text-[10px] text-slate-400 mt-2">Create a new scenario to adjust simulation parameters</p>
                </div>
              )}
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Simulation Parameters</h3>
                <button onClick={saveScenario} className="p-2 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                  <Save className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-10 pb-4">
                <SimulationSlider 
                  label="Vendor Compliance improvement" 
                  value={currentScenario.vendorImprovement} 
                  onChange={(v) => handleSliderChange('vendorImprovement', v)}
                />
                <SimulationSlider 
                  label="Mismatch Reduction Rate" 
                  value={currentScenario.mismatchReduction} 
                  onChange={(v) => handleSliderChange('mismatchReduction', v)}
                />
                <SimulationSlider 
                  label="Filing Speed Optimization" 
                  value={currentScenario.filingDelayReduction} 
                  onChange={(v) => handleSliderChange('filingDelayReduction', v)}
                />
                <SimulationSlider 
                  label="RCM Policy Offset" 
                  value={currentScenario.rcmExposureChange} 
                  min={-50} max={50}
                  onChange={(v) => handleSliderChange('rcmExposureChange', v)}
                />
              </div>
            </div>
          </div>

          {/* Impact Dashboard */}
          <div className="lg:col-span-3 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <ImpactCard 
                label="Exposure Liability" 
                value={`₹${calculateImpact(currentScenario).exposure.toFixed(2)} Cr`}
                baseline={`₹${baselineStats.exposure.toFixed(2)} Cr`}
                isPositive={false}
              />
              <ImpactCard 
                label="Optimized ITC Potential" 
                value={`₹${calculateImpact(currentScenario).itc.toFixed(2)} Cr`}
                baseline={`₹${baselineStats.itc.toFixed(2)} Cr`}
                isPositive={true}
              />
            </div>

            <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm h-[500px] flex flex-col">
              <div className="flex items-center justify-between mb-12">
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">Strategy Forecast</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Live Delta Analysis: {currentScenario.name}</p>
                </div>
                <div className="flex gap-8">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-blue-600"></span>
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Projected</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-slate-200"></span>
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Current</span>
                  </div>
                </div>
              </div>
              <div className="flex-1">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { name: 'Liability Exposure', current: baselineStats.exposure, projected: calculateImpact(currentScenario).exposure },
                    { name: 'ITC Recovered', current: baselineStats.itc, projected: calculateImpact(currentScenario).itc },
                  ]} barGap={12}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 900, fill: '#64748b', textTransform: 'uppercase'}} dy={10} />
                    <YAxis hide domain={[0, 'auto']} />
                    <Tooltip cursor={{fill: 'transparent'}} contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)', padding: '16px'}} />
                    <Bar dataKey="projected" fill="#2563eb" radius={[12, 12, 0, 0]} barSize={64} />
                    <Bar dataKey="current" fill="#f1f5f9" radius={[12, 12, 0, 0]} barSize={64} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Executive Comparison Dashboard */
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500">
          <div className="p-10 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-3xl font-black text-slate-900 tracking-tighter">Tax Strategy Matrix</h3>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-widest mt-2">Relative performance across all user-defined simulations</p>
          </div>
          <div className="p-10">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-100">
                    <th className="pb-6 text-left">Strategy Model</th>
                    <th className="pb-6 text-center">Exposure (Cr)</th>
                    <th className="pb-6 text-center">ITC Optimized (Cr)</th>
                    <th className="pb-6 text-center">Compliance</th>
                    <th className="pb-6 text-right">Relative Lift</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {scenarios.map(s => {
                    const res = calculateImpact(s);
                    const lift = ((res.itc - baselineStats.itc) / (baselineStats.itc || 1)) * 100;
                    return (
                      <tr key={s.id} className={`group ${editingId === s.id ? 'bg-blue-50/50' : 'hover:bg-slate-50/50'} transition-colors`}>
                        <td className="py-8">
                          <div className="flex items-center gap-4">
                            <div className={`w-3 h-3 rounded-full ${s.id === 'baseline' ? 'bg-slate-300' : 'bg-blue-600'} group-hover:scale-125 transition-transform`}></div>
                            <div>
                              <p className="text-lg font-black text-slate-900 tracking-tight">{s.name}</p>
                              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{s.id === 'baseline' ? 'Institutional Baseline' : 'Executive Strategy'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-8 text-center text-lg font-black text-slate-700 tabular-nums">₹{res.exposure.toFixed(2)}</td>
                        <td className="py-8 text-center text-lg font-black text-blue-600 tabular-nums">₹{res.itc.toFixed(2)}</td>
                        <td className="py-8 text-center">
                          <div className="inline-flex flex-col items-center">
                            <span className="text-lg font-black text-slate-900">{res.score.toFixed(1)}%</span>
                            <div className="w-20 h-2 bg-slate-100 rounded-full mt-2 overflow-hidden shadow-inner">
                              <div className="h-full bg-gradient-to-r from-blue-400 to-indigo-600" style={{width: `${res.score}%`}}></div>
                            </div>
                          </div>
                        </td>
                        <td className="py-8 text-right">
                          <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black tracking-tight ${lift >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                            {lift >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                            {Math.abs(lift).toFixed(2)}% Performance Shift
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          {/* Comparison Visualizer */}
          <div className="h-[400px] bg-slate-50/30 p-10 border-t border-slate-100">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData} margin={{top: 20, right: 30, left: 20, bottom: 5}}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 11, fontWeight: 900, fill: '#94a3b8', textTransform: 'uppercase'}} />
                <YAxis hide />
                <Tooltip cursor={{fill: 'rgba(241, 245, 249, 0.5)'}} />
                <Bar dataKey="Exposure" fill="#cbd5e1" radius={[8, 8, 0, 0]} barSize={40} />
                <Bar dataKey="ITC Recovery" radius={[8, 8, 0, 0]} barSize={40}>
                   {comparisonData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.id === 'baseline' ? '#94a3b8' : '#2563eb'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Persistence Success State */}
      {showSaveToast && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-8 py-4 rounded-3xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-bottom duration-500 z-50 border border-white/10 ring-1 ring-blue-500/20">
          <div className="bg-emerald-500 p-1.5 rounded-full shadow-lg shadow-emerald-500/20">
            <CheckCircle2 className="w-4 h-4 text-white" />
          </div>
          <span className="text-sm font-black tracking-tight uppercase tracking-widest">Configuration "{currentScenario.name}" Saved</span>
        </div>
      )}
    </div>
  );
};

const SimulationSlider: React.FC<{ label: string; value: number; min?: number; max?: number; onChange: (v: number) => void }> = ({ label, value, min = 0, max = 100, onChange }) => (
  <div className="space-y-5">
    <div className="flex justify-between items-center">
      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none">{label}</span>
      <span className="text-xs font-black text-blue-700 bg-blue-50 px-3 py-1.5 rounded-2xl border border-blue-100 shadow-sm tabular-nums transition-all hover:scale-110">
        {value}%
      </span>
    </div>
    <div className="relative h-6 flex items-center group">
      <div className="absolute w-full h-2 bg-slate-100 rounded-full shadow-inner"></div>
      <div className="absolute h-2 bg-gradient-to-r from-blue-400 to-indigo-600 rounded-full shadow-lg" style={{ width: `${((value - min) / (max - min)) * 100}%` }}></div>
      <input 
        type="range" 
        min={min} 
        max={max} 
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="absolute w-full appearance-none bg-transparent cursor-pointer z-10 
          [&::-webkit-slider-thumb]:appearance-none 
          [&::-webkit-slider-thumb]:w-6 
          [&::-webkit-slider-thumb]:h-6 
          [&::-webkit-slider-thumb]:bg-white 
          [&::-webkit-slider-thumb]:border-[3px] 
          [&::-webkit-slider-thumb]:border-blue-600 
          [&::-webkit-slider-thumb]:rounded-full 
          [&::-webkit-slider-thumb]:shadow-xl 
          [&::-webkit-slider-thumb]:transition-all 
          hover:[&::-webkit-slider-thumb]:scale-125 
          active:[&::-webkit-slider-thumb]:scale-90"
      />
    </div>
  </div>
);

const ImpactCard: React.FC<{ label: string; value: string; baseline: string; isPositive: boolean }> = ({ label, value, baseline, isPositive }) => {
  const vNum = parseFloat(value.replace('₹', '').replace(' Cr', ''));
  const bNum = parseFloat(baseline.replace('₹', '').replace(' Cr', ''));
  const diff = vNum - bNum;
  const improvement = isPositive ? diff > 0 : diff < 0;

  return (
    <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm relative group overflow-hidden transition-all hover:border-blue-300">
      <div className={`absolute top-0 right-0 w-32 h-32 opacity-[0.05] -mr-12 -mt-12 transition-transform duration-700 group-hover:scale-150 ${isPositive ? 'bg-emerald-500' : 'bg-blue-600'}`}></div>
      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em] mb-10">{label}</h4>
      <div className="flex items-end justify-between relative z-10">
        <div>
          <p className="text-4xl font-black text-slate-900 tracking-tighter">{value}</p>
          <div className="flex items-center gap-3 mt-4">
             <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-2xl text-[10px] font-black uppercase tracking-tight shadow-sm transition-colors ${improvement ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                {improvement ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                {Math.abs(diff).toFixed(2)} Cr Variance
             </span>
             <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">vs Baseline</span>
          </div>
        </div>
        <div className={`p-4 rounded-3xl transition-all group-hover:rotate-12 ${improvement ? 'bg-emerald-50' : 'bg-blue-50'}`}>
           <Play className={`w-6 h-6 ${improvement ? 'text-emerald-600' : 'text-blue-600'}`} />
        </div>
      </div>
    </div>
  );
};

export default ScenarioAnalysis;
