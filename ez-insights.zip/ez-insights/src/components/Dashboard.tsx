
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, Legend, AreaChart, Area 
} from 'recharts';
import { TrendingUp, TrendingDown, Info, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { GSTDataPoint } from '../types';

interface DashboardProps {
  data: GSTDataPoint[];
}

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const kpis = useMemo(() => {
    const total = data.reduce((acc, curr) => ({
      complianceScore: acc.complianceScore + curr.complianceScore,
      itcEfficiency: acc.itcEfficiency + (curr.claimedITC / (curr.eligibleITC || 1)) * 100,
      exposure: acc.exposure + curr.exposure,
      highRiskVendors: acc.highRiskVendors + curr.highRiskVendors,
      eligibleITC: acc.eligibleITC + curr.eligibleITC,
      blockedITC: acc.blockedITC + curr.blockedITC,
    }), { complianceScore: 0, itcEfficiency: 0, exposure: 0, highRiskVendors: 0, eligibleITC: 0, blockedITC: 0 });

    const count = data.length || 1;
    return {
      compliance: (total.complianceScore / count).toFixed(1),
      itcEfficiency: (total.itcEfficiency / count).toFixed(1),
      exposure: total.exposure.toFixed(2),
      riskCount: total.highRiskVendors,
      eligibleITC: total.eligibleITC,
      blockedITC: total.blockedITC,
    };
  }, [data]);

  const stateComparisonData = useMemo(() => {
    const map: Record<string, { state: string; exposure: number; itc: number }> = {};
    data.forEach(d => {
      if (!map[d.state]) map[d.state] = { state: d.state, exposure: 0, itc: 0 };
      map[d.state].exposure += d.exposure;
      map[d.state].itc += d.eligibleITC;
    });
    return Object.values(map).sort((a, b) => b.exposure - a.exposure);
  }, [data]);

  const itcComposition = [
    { name: 'Eligible ITC', value: kpis.eligibleITC, color: '#3b82f6' },
    { name: 'Blocked ITC', value: kpis.blockedITC, color: '#ef4444' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard 
          label="Compliance Health Index" 
          value={`${kpis.compliance}%`} 
          trend="+2.4%" 
          trendUp={true} 
          icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />} 
          color="emerald"
        />
        <KPICard 
          label="ITC Utilization Efficiency" 
          value={`${kpis.itcEfficiency}%`} 
          trend="-0.5%" 
          trendUp={false} 
          icon={<TrendingUp className="w-5 h-5 text-blue-500" />} 
          color="blue"
        />
        <KPICard 
          label="Total GST Exposure" 
          value={`₹${kpis.exposure} Cr`} 
          trend="+₹0.4 Cr" 
          trendUp={false} 
          icon={<ShieldAlert className="w-5 h-5 text-amber-500" />} 
          color="amber"
        />
        <KPICard 
          label="High-Risk GSTINs" 
          value={kpis.riskCount} 
          trend="+3" 
          trendUp={false} 
          icon={<Info className="w-5 h-5 text-slate-500" />} 
          color="slate"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Heatmap (Mocked as Bar) */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-800">GST Exposure by State</h3>
            <button className="text-xs font-semibold text-blue-600 hover:underline uppercase tracking-widest">View Heatmap</button>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stateComparisonData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="state" type="category" width={100} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="exposure" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* ITC Breakdown */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-6">ITC Composition</h3>
          <div className="h-[250px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={itcComposition}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {itcComposition.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">Eligible Amount</span>
              <span className="font-semibold">₹{kpis.eligibleITC.toFixed(1)} Cr</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">Blocked / Ineligible</span>
              <span className="font-semibold text-red-600">₹{kpis.blockedITC.toFixed(1)} Cr</span>
            </div>
          </div>
        </div>
      </div>

      {/* Trend line */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-slate-800">Compliance Mismatch Trend</h3>
          <div className="flex gap-2">
            <span className="flex items-center gap-1 text-xs font-medium text-slate-500">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span> GSTR-1
            </span>
            <span className="flex items-center gap-1 text-xs font-medium text-slate-500">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span> GSTR-3B
            </span>
          </div>
        </div>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorG1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="color3B" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="branch" hide />
              <YAxis hide />
              <Tooltip />
              <Area type="monotone" dataKey="gstr1" stroke="#3b82f6" fillOpacity={1} fill="url(#colorG1)" />
              <Area type="monotone" dataKey="gstr3b" stroke="#6366f1" fillOpacity={1} fill="url(#color3B)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const KPICard: React.FC<{ label: string; value: string | number; trend: string; trendUp: boolean; icon: React.ReactNode; color: string }> = ({ label, value, trend, trendUp, icon, color }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 relative overflow-hidden group hover:shadow-md transition-shadow">
      <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-sm font-medium text-slate-500">{label}</span>
        </div>
        <div className="flex items-baseline justify-between">
          <h2 className="text-2xl font-bold text-slate-900">{value}</h2>
          <span className={`text-xs font-bold flex items-center gap-0.5 ${trendUp ? 'text-emerald-600' : 'text-rose-600'}`}>
            {trendUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {trend}
          </span>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
